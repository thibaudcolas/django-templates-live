default_app_config = "slippers.apps.SlippersConfig"
